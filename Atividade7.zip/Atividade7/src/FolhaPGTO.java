public class FolhaPGTO {
    
    public static void main(String args[]) {

        Mensalista men1, men2;
        Horista hora1, hora2;

        System.out.println("==================================================");
        System.out.println("");
        
        men1 = new Mensalista("Jose", "Rua abc", "Junior");
        men1.calcularSalario();
        men1.calcularInss();
        men1.calcularIrpf();
        men1.imprimir();

        System.out.println("");
        System.out.println("==================================================");
        System.out.println("");

        men2 = new Mensalista("Ana", "Rua sem fim", "Senior");
        men2.calcularSalario();
        men2.calcularInss();
        men2.calcularIrpf();
        men2.imprimir();

        System.out.println("");
        System.out.println("==================================================");
        System.out.println("");

        hora1 = new Horista("Carlos", "Rua xyz", 20);
        hora1.calcularSalario();
        hora1.calcularInss();
        hora1.calcularIrpf();
        hora1.imprimir();

        System.out.println("");
        System.out.println("==================================================");
        System.out.println("");

        hora2 = new Horista("Cristina", "Rua do centro", 100);
        hora2.calcularSalario();
        hora2.calcularInss();
        hora2.calcularIrpf();
        hora2.imprimir();

        System.out.println("");
        System.out.println("==================================================");
    }

}
