public class Empregado {

    protected String nome;
    protected String endereco;
    protected double salario;


    public Empregado (String nome, String endereco) {
        this.nome = nome;
        this.endereco = endereco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public double getSalario() {
        return salario;
    }
    public void setSalario(double salario) {
        this.salario = salario;
    }

    public double calcularIrpf() {
        double aux;
        if (salario < 2112.01) {
            aux = 0;
        } else if (salario < 2826.66) {
            aux = 0.075 * salario - 158.4;
        } else if (salario < 3751.06) {
            aux = 0.15 * salario - 370.4;
        } else if (salario < 4664.69) {
            aux = 0.225 * salario - 651.73;
        } else {
            aux = 0.275 * salario - 884.96;
        }
        return (arredondar(aux));
    } 

    public double calcularInss() {
        double inss;
        if (salario <= 1320) {
            inss = 0.075 * salario;
        } else if (salario <= 2571.21) {
            inss = 0.09 * salario;
        } else if (salario <= 3856.94) {
            inss = 0.12 * salario;
        } else {
            inss = 0.14 * salario;
        }
        return (arredondar(inss));
    }

    private double arredondar(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }

    public void imprimir() {
        System.out.println("Nome: " + getNome());
        System.out.println("Endereço: " + getEndereco());
        System.out.println("Salário: " + getSalario());
        System.out.println("IRPF: " + calcularIrpf());
        System.out.println("INSS: " + calcularInss());
    }

}